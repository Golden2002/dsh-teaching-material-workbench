# 教师备课物料需求（研究笔记）

调研日期：2026-11-08。调研方式：联网检索 OECD、教师组织与 AI 教育研究，取一手或官方来源；证据不足处标“未核验”。原计划的独立调研 agent 未产出结果，本笔记由 Lead 直接检索补齐。

## 证据表

| 编号 | 结论 | 来源 | 强度 |
|---|---|---|---|
| T1 | 备课与课时计划是教师工作压力的主要来源之一，OECD TALIS 2024 把 lesson planning 列入压力因素 | [OECD, The demands of teaching: Results from TALIS 2024](https://www.oecd.org/en/publications/results-from-talis-2024_90df6235-en/full-report/the-demands-of-teaching_0e941e2f.html)，2026-11-08 访问 | 强（官方调查） |
| T2 | 教师大量时间花在找资源、做课件与改编材料上；数字资源要适配本班学生仍需二次加工 | [Public First, Teachers' perceptions of physical, digital and online resources](https://publicfirst.co.uk/wp-content/uploads/2021/05/Teachers-perceptions-of-physical-digital-and-online-resources-and-the-impact-of-Covid-19.pdf)，2026-11-08 访问 | 中（行业调查，样本与年份需核） |
| T3 | 1,036 名教师的课时准备研究给出时间分配，备课与评分占课外时间大头 | [EdTechReview, Teacher Lesson Preparation: What a Study of 1,036 Teachers Found](https://www.edtechreview.in/data-statistics/what-teachers-really-spend-their-time-on-discover-study-of-1-036-teachers-found/)，2026-11-08 访问 | 弱（二手转述，需回查原始研究，未核验） |
| T4 | 教师需要“可审查、可控制”的生成式 AI 界面，而不是黑箱一键生成；scrutable interface 让教师看见并改写 AI 的结构与依据 | [Concept Catalyst: Exploring Scrutable Interfaces to Structure K-12 Teacher Interactions with Generative AI](https://raw.githubusercontent.com/edtechdev/aied/refs/heads/main/content/en/articles/concept-catalyst-k12-teacher.md)，2026-11-08 访问 | 中（会议论文预印本） |
| T5 | 教师对 AI 的信任取决于能否核对来源、能否保留自己的教学判断，以及出错后能否回退 | 由 T1–T4 归纳；直接证据未核验 | 弱（待访谈验证） |

## 教师任务与卡点

一位教师备一节课的路径：

1. 定主题与目标：从教材、课标、考试要求里取内容，转成可观察目标。卡点：目标写得空，后面活动与评分对不上。
2. 找一手材料：教材、官方指南、原版文章、数据。卡点：来源分散，二手转述混入，版权不清。
3. 排时间轴：每个环节几分钟、教师做什么、学生做什么、产出什么。卡点：时间超了，活动与目标脱节。
4. 写讲义与课件：同一份内容写成学生讲义、投影要点、教师讲稿三套。卡点：三套各改一遍，版本对不上。
5. 做视频或动画：写分镜、录屏、配音、加字幕、渲染。卡点：工具门槛高，Manim 要写代码，渲染环境另装。
6. 试讲与修改：按时间走一遍，改语言、改活动、补例子。卡点：改完不知道哪版是上课版。
7. 上课与复盘：发讲义、放课件、留作业。卡点：没有可回溯的版本与来源记录。

## 教师希望工作台做什么

- 一份内容源，派生讲义、课件、讲稿、分镜，不让我三套各改一遍。
- 逐页改，旁边即时看到讲义与课件的近似效果；改哪页看哪页。
- 每页能看见它引用了哪条来源；没来源的句子标出来，我自己决定改述、补来源还是删。
- 语言问题能定位到行、能一键改机械项，比喻与长句留给我判断。
- 保存就是版本；改坏了能回到上一版；导出后能对上哈希。
- 视频与动画先给我分镜和可运行的 Manim 脚本；渲染失败要如实说失败，不要假装成功。

## 教师不希望工作台做什么

- 不替我做“一键通过”或“忽略此项”，检查结论必须留痕。
- 不把我没确认的 AI 改写直接写进正文。
- 不内嵌完整 PPT 编辑器，不托管视频，不做学生数据平台。
- 不把教材原文整段搬进系统；只记录定位与允许的短引文。

## 对插件的直接要求（已落地或列入路线）

| 要求 | 状态 | 对应实现 |
|---|---|---|
| 一份页数据派生多类物料 | 已实现 | `pages.json`、`teaching_material_pages`、`build/outline.md` |
| 逐页编辑与近似预览 | 已实现 | Web UI「逐页」标签 |
| 导出讲义、课件、分镜、Manim 脚本 | 已实现 | `teaching_material_export`；本机 python-docx/python-pptx 可用时出 DOCX/PPTX，缺失时降级说明 |
| 检查中心与版本回退 | 已实现 | `/api/checks`、`.history/`、UI「检查中心」「版本回退」 |
| 来源逐条核对 | 部分实现 | `sources.csv` + `E2-sources`；页级 `sources[]`；句级未接地提示未做 |
| 视频与 Manim 渲染 | 未做 | 只生成脚本；本机缺 manim/ffmpeg，未安装 |

## 边界

- T3 是二手转述，未回查原始研究；不把它当硬数据。
- 教师信任与可审查性的判断来自 T4 与设计常识，需真实教师试讲验证（E3 未执行）。
- 不同学段、学科对“讲义”的定义不同；插件只提供结构，不规定教学法。
